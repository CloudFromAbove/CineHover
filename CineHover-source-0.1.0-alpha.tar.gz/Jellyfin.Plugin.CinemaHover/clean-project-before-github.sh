#!/usr/bin/env bash
set -euo pipefail

APPLY="false"

if [[ "${1:-}" == "--apply" ]]; then
    APPLY="true"
fi

ROOT="$(pwd)"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="$ROOT/.cleanup-backups"
BACKUP_FILE="$BACKUP_DIR/project-before-clean-$STAMP.tar.gz"

echo "CinemaHover cleanup"
echo "Root: $ROOT"
echo "Mode: $([[ "$APPLY" == "true" ]] && echo "APPLY" || echo "DRY-RUN")"
echo

if [[ ! -f "$ROOT/Jellyfin.Plugin.CinemaHover.csproj" ]]; then
    echo "ERREUR : lance ce script depuis le dossier contenant Jellyfin.Plugin.CinemaHover.csproj"
    exit 1
fi

mkdir -p "$BACKUP_DIR"

echo "Création d'une sauvegarde :"
echo "$BACKUP_FILE"
tar \
    --exclude="./bin" \
    --exclude="./obj" \
    --exclude="./.git" \
    --exclude="./.cleanup-backups" \
    -czf "$BACKUP_FILE" \
    .

echo
echo "Recherche des éléments à nettoyer..."
echo

mapfile -t TARGETS < <(
    find "$ROOT" \
        \( \
            -path "$ROOT/bin" -o \
            -path "$ROOT/obj" -o \
            -path "$ROOT/dist" -o \
            -path "$ROOT/.vs" -o \
            -path "$ROOT/.vscode/.history" -o \
            -path "$ROOT/TestResults" -o \
            -path "$ROOT/coverage" \
        \) -prune -print

    find "$ROOT" -type f \
        \( \
            -name "*.log" -o \
            -name "*.tmp" -o \
            -name "*.bak" -o \
            -name "*.orig" -o \
            -name "*.rej" -o \
            -name "*.before-*" -o \
            -name "patch-phase*.py" -o \
            -name "patch-*.py" -o \
            -name "Texte collé*.txt" -o \
            -name ".DS_Store" -o \
            -name "Thumbs.db" \
        \) -print

    find "$ROOT" -type f \
        \( \
            -name "*.dll" -o \
            -name "*.pdb" -o \
            -name "*.deps.json" -o \
            -name "*.runtimeconfig.json" \
        \) \
        ! -path "$ROOT/Web/Assets/*" \
        ! -path "$ROOT/.cleanup-backups/*" \
        -print
)

if [[ "${#TARGETS[@]}" -eq 0 ]]; then
    echo "Aucun élément temporaire trouvé."
    exit 0
fi

printf '%s\n' "${TARGETS[@]}" | sed "s#^$ROOT/##" | sort

echo
if [[ "$APPLY" != "true" ]]; then
    echo "Dry-run uniquement. Rien n'a été supprimé."
    echo "Pour appliquer réellement :"
    echo "  ./clean-project-before-github.sh --apply"
    exit 0
fi

echo "Suppression..."
for target in "${TARGETS[@]}"; do
    if [[ -e "$target" ]]; then
        rm -rf "$target"
    fi
done

echo
echo "Nettoyage terminé."
echo "Sauvegarde conservée ici :"
echo "$BACKUP_FILE"
